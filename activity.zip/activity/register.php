<!DOCTYPE html>
<html>
<head>
	<?php include_once "etc/head.php"; ?>
	<?php 
		if(isset($_SESSION['user'])){
			echo "<script>window.location = 'home.php';</script>";
		}
	?>
	<title>Activity 1</title>
</head>
<body>
	<div class="container mx-auto mt-5">
		<div class="col-6 mx-auto">
			<div class="container text-center text-danger bg-warning errorMes" id="regError">
			</div>
			<div class="border rounded mt-3">
				<div class="col d-flex justify-content-center pt-5">
					<label class="lead">Register Here</label>
				</div>
				<div class="col mt-3">
					<form method="post">
					  <div class="form-group">
					    <label for="Firstname">Firstname</label>
					    <input type="text" name="fname" value="<?php echo isset($_POST['fname']) ? $_POST['fname'] : '' ?>" required class="form-control" id="Firstname" placeholder="Enter Firstname">
					  </div>
					  <div class="form-group">
					    <label for="Lastname">Lastname</label>
					    <input type="text" name="lname" value="<?php echo isset($_POST['lname']) ? $_POST['lname'] : '' ?>" required class="form-control" id="Lastname" placeholder="Enter Lastname">
					  </div>
					  <div class="form-group">
					    <label for="Username">Username</label>
					    <input type="text" name="uname" value="<?php echo isset($_POST['uname']) ? $_POST['uname'] : '' ?>" required class="form-control" id="Username" placeholder="Enter Username">
					  </div>
					  <div class="form-group">
					    <label for="password">Password</label>
					    <input type="password" name="passwordUser" value="<?php echo isset($_POST['passwordUser']) ? $_POST['passwordUser'] : '' ?>" required class="form-control" id="password" placeholder="Password">
					  </div>
					  <div class="form-group">
					    <label for="repassword">Retype Password</label>
					    <input type="password" name="passwordRetype" value="<?php echo isset($_POST['passwordRetype']) ? $_POST['passwordRetype'] : '' ?>" required class="form-control" id="repassword" placeholder="Retype Password">
					  </div>
					  <div>
					  	<button type="submit" class="btn btn-primary btn-lg btn-block" name="registerSubmit">Submit</button>
					  </div>
					</form>
				</div>	
				<div class="container-fluid border rounded bg-light pt-2 mt-3 border-top text-center">
					<label>
						<a href="index.php">Login Instead?</a>
					</label>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

<?php 
	include_once "process.php";
?>