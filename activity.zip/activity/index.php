<!DOCTYPE html>
<html>
<head>
	<?php include_once "etc/head.php"; ?>
	<?php 
		if(isset($_SESSION['user'])){
			echo "<script>window.location = 'home.php';</script>";
		}
	?>

	<title>Activity 1</title>
</head>
<body>
	<div class="container mx-auto mt-5">
		<div class="col-6 mx-auto">
			<div class="container bg-warning text-center errorMes" id="logError">
				
			</div>
			<div class="border rounded">
				<div class="col d-flex justify-content-center pt-5">
					<label class="lead">Login Here</label>
				</div>
				<form method="POST">
					<div class="col mt-3">
						  <div class="form-group">
						    <label for="Username">Username</label>
						    <input type="text" required class="form-control" name="uname" id="Username" placeholder="Enter Username">
						  </div>
						  <div class="form-group">
						    <label for="password">Password</label>
						    <input type="password" name="password" required class="form-control" id="password" placeholder="Password">
						  </div>
						  <div>
						  	<button type="submit" class="btn btn-primary btn-lg btn-block" name="submitLogin">Submit</button>
						  </div>
					</div>
				</form>
				<div class="container-fluid border rounded bg-light pt-2 mt-3 border-top text-center">
					<label>
						<a href="register.php">Need Account?</a>
					</label>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

<?php include_once "process.php"; ?>