<link rel="stylesheet" type="text/css" href="etc/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="etc/css/custom.css">
<script type="text/javascript" href="etc/js/jquery.min.js"></script>
<script type="text/javascript" href="etc/js/bootstrap.min.js"></script>
<script type="text/javascript" href="etc/js/popper.js"></script>
<?php 
	session_start();
?>