<!DOCTYPE html>
<html>
<head>
	<?php include_once "etc/head.php"; ?>
	<?php 
		if(!isset($_SESSION['user'])){
			echo "<script>window.location = 'home.php';</script>";
		}
	?>
	<title>Edit</title>
</head>
<body>


	<div class="container mx-auto mt-5">
		<div class="col-6 mx-auto">
			<div class="container text-center text-danger bg-warning errorMes" id="editError">
			</div>
			<?php 
				include_once "process.php";
			?>
			<div class="border rounded mt-3">
				<div class="col d-flex justify-content-center pt-5">
					<label class="lead">Edit Here</label>
				</div>
				<div class="col mt-3">
					<form method="POST">
					  <div class="form-group">
					    <label for="Firstname">Firstname</label>
					    <input type="text" name="fname" value="<?php echo $fname;?>" required class="form-control" id="Firstname" placeholder="Enter Firstname">
					    <input type="hidden" name="id" value="<?php echo $id; ?>">
					    <input type="hidden" name="passwordVerify" value="<?php echo $password; ?>">
					  </div>
					  <div class="form-group">
					    <label for="Lastname">Lastname</label>
					    <input type="text" name="lname" value="<?php echo $lname; ?>" required class="form-control" id="Lastname" placeholder="Enter Lastname">
					  </div>
					  <div class="form-group">
					    <label for="Username">Username</label>
					    <input type="text" name="uname" value="<?php echo $uname;?>" required class="form-control" id="Username" placeholder="Enter Username">
					  </div>
					  <div class="form-group">
					    <label for="password">Current Password</label>
					    <input type="password" name="passwordUser" required class="form-control" id="password" placeholder="Current password">
					  </div>
					  <div class="form-group">
					    <label for="password">New Password</label>
					    <input type="password" name="newPassword" class="form-control" id="password" placeholder="Current password">
					  </div>
					  <div class="form-group">
					    <label for="password">Confirm Password</label>
					    <input type="password" name="confirmPassword" class="form-control" id="password" placeholder="Confirm password">
					  </div>
					  <div>
					  	<button type="submit" class="btn btn-primary btn-lg btn-block" name="updateSubmit">Submit</button>
					  	<button type="button" onclick="window.location='home.php';" class="btn btn-lg btn-block green" name="updateSubmit">Back</button>
					  </div>
					</form>
				</div>	
			</div>
		</div>
	</div>
</body>
</html>
