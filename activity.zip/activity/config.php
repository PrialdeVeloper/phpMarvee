<?php 
$dbname = 'activity';
$host = 'localhost';
$user = 'root';
$password = '';
$db = null;

try {
	$db = new PDO("mysql: host=$host;dbname=$dbname",$user,$password);
} catch (Exception $e) {
	echo $e->getMessage();
}


?>