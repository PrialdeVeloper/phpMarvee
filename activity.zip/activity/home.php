<!DOCTYPE html>
<html>
<head>
	<?php include_once "etc/head.php"; ?>
	<title>Home</title>
	<?php 
		if(!isset($_SESSION['user'])){
			echo "<script>window.location='index.php'</script>";
		}
	?>
</head>
<body>
	<?php include_once "process.php"; ?>
	<div class="container mx-auto mt-5 text-center">
		<div class="col-12 mx-auto border border-secondary">
			<div class="table-responsive">
				<table class="table table-striped">
				  <thead>
				    <tr>
				      <th scope="col">userID</th>
				      <th scope="col">Firstname</th>
				      <th scope="col">Lastname</th>
				      <th scope="col">Username</th>
				      <th scope="col">Password</th>
				      <th scope="col">Registration Time and Date</th>
				      <th scope="col">Action</th>
				    </tr>
				  </thead>
				  <tbody>
				    <?php echo $dom; ?>
				  </tbody>
				</table>
			</div>

			<div class="d-flex justify-content-center">
				<nav>
				  <ul class="pagination">
				    <li class="page-item <?php if($_GET['page'] == 1){echo "disabled";} ?>"><a class="page-link" href="?page=1">First</a></li>
				    <li class="page-item <?php if($_GET['page'] <= 1){ echo 'disabled'; } ?>"><a class="page-link" href="<?php  if($_GET['page'] <= 1){ echo '#'; }else{echo '?page='.($_GET['page'] - 1);} ?>">Prev</a></li>
				    <li class="page-item <?php if($_GET['page'] >= $totalPages){ echo 'disabled'; } ?>"><a class="page-link" href="<?php if($_GET['page'] >= $totalPages){ echo '#'; }else{echo '?page='.($_GET['page'] + 1);} ?>">Next</a></li>
				    <li class="page-item <?php if($_GET['page'] >= $totalPages){echo "disabled";} ?>"><a class="page-link" href="<?php echo "?page=".$totalPages; ?>">Last</a></li>
				  </ul>
				</nav>
			</div>

			<form method="GET">
				<button type="submit" onclick="return confirm('Sure to logout?');" name="signout" class="btn btn-primary">Logout</button>
			</form>
		</div>
	</div>
</body>
</html>
